"""Run fixed scalar branch models and publish validated output files together."""

import json
import math
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

from nwkit import __version__
from nwkit.branch_gaussian import build_branch_gaussian_process
from nwkit.branch_gaussian_input import load_branch_gaussian_assignment
from nwkit.continuous_asr_io import continuous_output_table
from nwkit.gaussian_inference import (
    GaussianConditioningResult,
    condition_gaussian_tree,
    gaussian_tree_likelihood,
    simulate_gaussian_process,
)
from nwkit.gaussian_tree import GaussianRootPrior
from nwkit.output_transaction import output_transaction, validate_output_targets
from nwkit.rooting_state import require_rooted
from nwkit.trait_input import numeric_trait_value, parse_trait_columns
from nwkit.util import (
    assign_branch_ids,
    get_node_class,
    read_tip_table,
    read_tree,
    validate_outputs_do_not_replace_inputs,
    validate_unique_named_leaves,
)

_INPUTS = ("infile", "trait", "branch_models", "branch_regimes", "regime_models")
_OUTPUTS = ("outfile", "model_out", "models_out")
_MODEL_COLUMNS = (
    "branch_id",
    "model",
    "sigma2",
    "alpha",
    "theta",
    "jump_mean",
    "jump_variance",
)
_MAX_SIMULATION_VALUES = 2_000_000


def _root(args):
    mode = args.root_prior
    if mode == "flat":
        if args.root_mean is not None or args.root_variance is not None:
            raise ValueError(
                "A flat root does not accept --root-mean or --root-variance."
            )
        root = GaussianRootPrior("flat", variance=None)
    else:
        if args.root_mean is None:
            raise ValueError("--root-mean is required for a proper root.")
        if mode == "fixed" and args.root_variance is not None:
            raise ValueError("A fixed root has variance zero; omit --root-variance.")
        root = GaussianRootPrior(
            mode, args.root_mean, 0.0 if mode == "fixed" else args.root_variance
        )
    if args.mode == "simulate" and mode == "flat":
        if args.root_value is None or not math.isfinite(args.root_value):
            raise ValueError("Flat-root simulation requires a finite --root-value.")
    elif args.root_value is not None:
        raise ValueError("--root-value is only used for flat-root prior simulation.")
    return root


def _options(args):
    if args.mode == "simulate":
        if any(
            getattr(args, name) is not None
            for name in ("trait", "state_column", "standard_error_column", "ci_level")
        ):
            raise ValueError(
                "Prior simulation does not accept trait, SE or interval options."
            )
        if args.n_sim is None:
            args.n_sim = 1000
        if args.seed is None:
            args.seed = 1
        if not 1 <= args.n_sim <= 10000 or args.seed < 0:
            raise ValueError("--n-sim must be 1–10000 and --seed must be nonnegative.")
    else:
        if args.trait in (None, "") or args.state_column in (None, ""):
            raise ValueError(
                "--trait and --state-column are required for asr/likelihood."
            )
        if args.n_sim is not None or args.seed is not None:
            raise ValueError("--n-sim and --seed are only used for prior simulation.")
    if args.mode == "asr":
        if args.ci_level is None:
            args.ci_level = 0.95
        if not math.isfinite(args.ci_level) or not 0 < args.ci_level < 1:
            raise ValueError("--ci-level must be finite and strictly between 0 and 1.")
    elif args.ci_level is not None:
        raise ValueError("--ci-level is only used for ASR.")
    paths = {}
    for role in _OUTPUTS:
        path = getattr(args, role)
        if (
            path == ""
            or (path == "-" and role != "outfile")
            or (path is None and role == "outfile")
        ):
            raise ValueError(f"Invalid output path for --{role.replace('_', '-')}.")
        if path not in (None, "-"):
            paths[role] = path
    validate_outputs_do_not_replace_inputs(
        [("--" + role.replace("_", "-"), getattr(args, role)) for role in _INPUTS],
        [("--" + role.replace("_", "-"), path) for role, path in paths.items()],
    )
    validate_output_targets(paths.values())
    return paths, _root(args)


def _observations(args, tree):
    columns = parse_trait_columns(args.state_column)
    if len(columns) != 1:
        raise ValueError("branchgaussian currently requires one scalar --state-column.")
    if args.standard_error_column is not None:
        columns += parse_trait_columns(args.standard_error_column)
        if len(columns) != 2 or len(set(columns)) != 2:
            raise ValueError("Provide one SE column different from the trait column.")
    names = [str(node.name) for node in tree.leaves()]
    table, _, _ = read_tip_table(
        args.trait,
        tree_leaf_names=names,
        required_columns=columns,
        missing_values=args.missing_values,
        unmatched=args.unmatched,
    )
    table = table.set_index("leaf_name").reindex(names)
    values, errors = {}, {}
    for name in names:
        value = numeric_trait_value(
            table.loc[name, columns[0]], columns[0], args.missing_values
        )
        values[name] = None if np.isnan(value) else value
        error = 0.0
        if args.standard_error_column is not None:
            error = numeric_trait_value(
                table.loc[name, columns[1]], columns[1], args.missing_values
            )
            if np.isnan(error):
                if values[name] is not None:
                    raise ValueError(
                        f"Missing standard error for observed tip '{name}'."
                    )
                error = 0.0
            if error < 0:
                raise ValueError(f"Negative standard error for tip '{name}'.")
        errors[name] = error
    if not any(value is not None for value in values.values()):
        raise ValueError("At least one observed trait value is required.")
    return values, errors


def _node_rows(tree):
    identifiers = assign_branch_ids(tree)
    return [
        {
            "branch_id": identifier,
            "parent": -1 if node.is_root else identifiers[node.up],
            "node_class": get_node_class(node),
            "name": str(node.name or ""),
            "length": None if node.is_root else float(node.dist),
        }
        for node, identifier in identifiers.items()
    ]


def _simulate(args, process):
    if len(process.transitions) + 1 > _MAX_SIMULATION_VALUES // args.n_sim:
        raise ValueError(
            "Prior simulation output exceeds the 2 million node-value limit; reduce --n-sim."
        )
    samples = simulate_gaussian_process(
        process, num_samples=args.n_sim, seed=args.seed, root_values=args.root_value
    )
    identifiers = assign_branch_ids(process.tree)
    records = [
        {
            "branch_id": identifiers[node],
            "parent": -1 if node.is_root else identifiers[node.up],
            "node_class": get_node_class(node),
            "name": str(node.name or ""),
        }
        for node in samples.nodes
    ]
    table = pd.concat([pd.DataFrame(records)] * args.n_sim, ignore_index=True)
    table.insert(
        0, "simulation", np.repeat(np.arange(1, args.n_sim + 1), len(samples.nodes))
    )
    table["value"] = samples.values.ravel()
    return table


def _infer(args, process, values, errors):
    operation = (
        condition_gaussian_tree if args.mode == "asr" else gaussian_tree_likelihood
    )
    result = operation(process, values, standard_errors=errors)
    summary = {
        "model": "branch-heterogeneous",
        "trait": args.state_column,
        "root_prior": process.root.mode,
        "log_likelihood": result.log_likelihood,
        "likelihood_rank": result.likelihood_rank,
        "num_observed": result.num_observed,
        "num_observed_positions": result.num_observed_positions,
    }
    if args.mode == "likelihood":
        return pd.DataFrame([summary]), summary
    assert isinstance(result, GaussianConditioningResult)
    return continuous_output_table(
        process.tree,
        list(process.tree.traverse("levelorder")),
        values,
        errors,
        result.marginals,
        trait=args.state_column,
        ci_level=args.ci_level,
    ), summary


def branch_gaussian_main(args):
    paths, root = _options(args)
    tree = read_tree(
        args.infile, args.format, args.quoted_node_names, rooted=args.input_rooted
    )
    require_rooted(tree, "branchgaussian requires a rooted tree.")
    validate_unique_named_leaves(tree, "--infile")
    assignment = load_branch_gaussian_assignment(
        tree,
        branch_models=args.branch_models,
        branch_regimes=args.branch_regimes,
        regime_models=args.regime_models,
    )
    process = build_branch_gaussian_process(
        tree, assignment.models_by_branch_id, root=root
    )
    values, errors, summary = {}, {}, None
    if args.mode == "simulate":
        table = _simulate(args, process)
    else:
        values, errors = _observations(args, tree)
        table, summary = _infer(args, process, values, errors)
    model_rows = assignment.model_rows()
    identifiers = assign_branch_ids(tree)
    metadata = {
        "schema_version": 1,
        "nwkit_version": __version__,
        "command": "branchgaussian",
        "mode": args.mode,
        "parameters": "fixed; no parameter estimation or model search",
        "root": asdict(root),
        "nodes": _node_rows(tree),
        "branch_models": model_rows,
        "branch_regimes": None
        if assignment.regime_by_branch_id is None
        else [
            {"branch_id": key, "regime": value}
            for key, value in sorted(assignment.regime_by_branch_id.items())
        ],
        "transitions": [
            {"branch_id": identifiers[node], **asdict(transition)}
            for node, transition in process.transitions.items()
        ],
        "jump_position": "branch_end_after_diffusion",
        "observations": [
            {"leaf_name": name, "value": value, "standard_error": errors[name]}
            for name, value in values.items()
        ],
        "state_column": args.state_column,
        "standard_error_column": args.standard_error_column,
        "missing_values": args.missing_values,
        "unmatched": args.unmatched,
        "ci_level": args.ci_level,
        "n_sim": args.n_sim,
        "seed": args.seed,
        "root_value": args.root_value,
        "inference": summary,
        "uncertainty": "Conditional on fixed tree, branch assignments and parameters. Simulation draws latent prior states without observation noise. Flat-root likelihoods use an improper constant-density root and are not comparable to proper-root likelihoods.",
    }
    serialized = {
        "outfile": table.to_csv(sep="\t", index=False, float_format="%.17g"),
        "models_out": pd.DataFrame(model_rows, columns=_MODEL_COLUMNS).to_csv(
            sep="\t", index=False, float_format="%.17g"
        ),
        "model_out": json.dumps(metadata, ensure_ascii=False, allow_nan=False, indent=2)
        + "\n",
    }
    with output_transaction(paths.values()) as staged:
        for role, path in paths.items():
            Path(staged[path]).write_text(serialized[role], encoding="utf-8")
    if args.outfile == "-":
        sys.stdout.write(serialized["outfile"])
    return 0
