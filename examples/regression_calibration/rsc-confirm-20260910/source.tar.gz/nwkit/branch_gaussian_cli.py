"""CLI registration for fixed branch-specific scalar Gaussian processes."""


def register_branch_gaussian(subparsers, tree_input, table_output, table_policy):
    parser = subparsers.add_parser(
        "branchgaussian",
        parents=[tree_input, table_output, table_policy],
        help="Fixed branch-specific BM/OU/Gaussian-jump likelihood, ASR and simulation.",
    )
    parser.add_argument(
        "--mode",
        choices=["asr", "likelihood", "simulate"],
        default="asr",
        help="Operation (default asr); simulate draws latent values from the prior.",
    )
    assignments = parser.add_mutually_exclusive_group(required=True)
    assignments.add_argument(
        "--branch-models",
        "--branch_models",
        help="Direct branch_id/model/parameter TSV; excludes root 0.",
    )
    assignments.add_argument(
        "--branch-regimes",
        "--branch_regimes",
        help="Complete branch_id/regime TSV; excludes root 0.",
    )
    parser.add_argument(
        "--regime-models",
        "--regime_models",
        help="Regime/model/parameter TSV, required with --branch-regimes.",
    )
    parser.add_argument(
        "--root-prior",
        "--root_prior",
        choices=["fixed", "gaussian", "stationary", "flat"],
        required=True,
        help="Explicit root prior; stationary requires user-supplied mean and variance.",
    )
    parser.add_argument(
        "--root-mean",
        "--root_mean",
        type=float,
        help="Required for fixed/Gaussian/stationary roots; not inferred.",
    )
    parser.add_argument(
        "--root-variance",
        "--root_variance",
        type=float,
        help="Required positive absolute variance for Gaussian/stationary roots.",
    )
    parser.add_argument(
        "--root-value",
        "--root_value",
        type=float,
        help="Required starting value for flat-root prior simulation only.",
    )
    parser.add_argument(
        "--trait", help="Tip-keyed trait TSV, required for asr/likelihood."
    )
    parser.add_argument(
        "--state-column",
        "--state_column",
        help="Numeric trait column, required for asr/likelihood.",
    )
    parser.add_argument(
        "--standard-error-column",
        "--standard_error_column",
        help="Optional nonnegative observation standard deviations, not variances.",
    )
    parser.add_argument(
        "--ci-level",
        "--ci_level",
        type=float,
        help="ASR conditional interval level (default .95).",
    )
    parser.add_argument(
        "--n-sim",
        "--n_sim",
        type=int,
        help="Prior draws for simulate only (default 1000, range 1–10000; at most 2 million node values).",
    )
    parser.add_argument(
        "--seed", type=int, help="Nonnegative simulation seed (default 1)."
    )
    parser.add_argument(
        "--model-out",
        "--model_out",
        help="Optional JSON of topology, parameters, observations and run settings.",
    )
    parser.add_argument(
        "--models-out",
        "--models_out",
        help="Optional normalized direct branch-model TSV for reuse with --branch-models.",
    )
    parser.set_defaults(handler=_command_branch_gaussian)


def _command_branch_gaussian(args):
    from nwkit.branch_gaussian_run import branch_gaussian_main

    return branch_gaussian_main(args)
