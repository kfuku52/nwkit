"""Independent data generation for fixed-model regression calibration.

This is a validation tool, not a production estimator. In particular, the RSC
event-balanced objective is composite; its working covariance is not a claim
that it defines an ordinary Gaussian likelihood.
"""

import hashlib
import json
from dataclasses import asdict, dataclass, replace

import numpy as np
from scipy.special import expit


@dataclass(frozen=True)
class Case:
    name: str
    engine: str = "rsc"
    size: int = 20
    copies: int = 1
    concentrated: bool = False
    predictors: int = 1
    correlation: float = 0.0
    beta: float = 0.0
    event_variance: float = 0.0
    lineage_variance: float = 0.0
    sampling_variance: float = 0.0
    biological_replicates: int = 1
    estimated_se: bool = False
    predictor_variance: float = 0.0
    missing: float = 0.0
    missing_mechanism: str = "mcar"
    working_covariance_dgm: bool = False
    family: str = "binomial"
    phylogenetic_variance: float = 0.5
    baseline: float = 0.5
    dispersion: float = 2.0
    zero_inflation: float = 0.0
    count_error: float = 0.0
    tree_shape: str = "balanced"


def seed_for(seed, case_name, replicate, stream):
    """Stable streams independent of methods, ordering, workers and sharding."""
    payload = json.dumps([int(seed), case_name, int(replicate), stream]).encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def cases():
    result = [Case(f"rsc-e{n}", size=n) for n in (2, 3, 5, 10, 20, 50)]
    for n in (5, 20):
        base = Case(f"rsc-e{n}-copies5", size=n, copies=5, event_variance=0.5)
        result.extend(
            [
                base,
                replace(base, name=base.name + "-boundary", event_variance=0.0),
                replace(base, name=base.name + "-concentrated", concentrated=True),
                replace(base, name=base.name + "-working", working_covariance_dgm=True),
                replace(base, name=base.name + "-lineage", lineage_variance=0.5),
            ]
        )
    base = Case("rsc-e20-replicates", sampling_variance=1.0, biological_replicates=5)
    result.extend(
        [
            base,
            replace(base, name=base.name + "-estimated-se", estimated_se=True),
            replace(base, name=base.name + "-predictor-error", predictor_variance=0.5),
            Case("rsc-e20-joint-rho09", predictors=2, correlation=0.9),
            Case("rsc-e20-joint-rho099", predictors=2, correlation=0.99),
            Case("rsc-e2-rank-ineligible", size=2, predictors=2),
        ]
    )
    for mechanism in ("mcar", "mar", "mnar", "clade"):
        result.append(
            Case(
                f"rsc-e20-missing-{mechanism}", missing=0.3, missing_mechanism=mechanism
            )
        )
    for n in (8, 30, 60):
        for baseline in (0.5, 0.05):
            result.append(
                Case(
                    f"binomial-n{n}-p{baseline}",
                    engine="glmm",
                    size=n,
                    baseline=baseline,
                )
            )
    for family in ("binomial", "poisson", "negative-binomial"):
        base = Case(
            f"{family}-n30",
            engine="glmm",
            size=30,
            family=family,
            baseline=0.5 if family == "binomial" else 2.0,
        )
        if family != "binomial":
            result.append(base)
        result.extend(
            [
                replace(base, name=base.name + "-boundary", phylogenetic_variance=0.0),
                replace(
                    base,
                    name=base.name + "-strong-phylogeny",
                    phylogenetic_variance=2.0,
                ),
                replace(
                    base,
                    name=base.name + "-missing-mar",
                    missing=0.3,
                    missing_mechanism="mar",
                ),
                replace(
                    base, name=base.name + "-count-error", beta=0.5, count_error=0.3
                ),
            ]
        )
    result.extend(
        [
            Case("binomial-n30-comb", engine="glmm", size=30, tree_shape="comb"),
            Case(
                "poisson-n30-zero-inflation",
                engine="glmm",
                size=30,
                family="poisson",
                baseline=2.0,
                zero_inflation=0.3,
            ),
            Case(
                "negative-binomial-n30-poisson-limit",
                engine="glmm",
                size=30,
                family="negative-binomial",
                baseline=2.0,
                dispersion=1e6,
            ),
            Case("rsc-e20-alternative", beta=0.5),
            Case("binomial-n30-alternative", engine="glmm", size=30, beta=0.5),
        ]
    )
    assert len({case.name for case in result}) == len(result)
    return result


def tree_covariance(n, shape="balanced"):
    """Brownian covariance computed from shared edges, without NWKIT helpers."""
    covariance = np.zeros((n, n))

    def visit(indices):
        if len(indices) == 1:
            covariance[indices[0], indices[0]] += 1.0
            return f"S{indices[0]}:1"
        cut = 1 if shape == "comb" else len(indices) // 2
        children = []
        for child in (indices[:cut], indices[cut:]):
            if len(child) > 1:
                covariance[np.ix_(child, child)] += 1.0
            children.append(visit(child))
        return "(" + ",".join(children) + "):1"

    newick = visit(list(range(n))).rsplit(":1", 1)[0] + ";"
    covariance /= np.mean(np.diag(covariance))
    return newick, covariance


def observed_mask(rng, case, x, y, groups):
    if case.missing == 0:
        return np.ones(len(y), dtype=bool)
    if case.missing_mechanism == "mcar":
        probability = np.full(len(y), case.missing)
    elif case.missing_mechanism in {"mar", "mnar"}:
        score = x[:, 0] if case.missing_mechanism == "mar" else y
        score = (score - np.mean(score)) / max(np.std(score), 1e-12)
        probability = expit(np.log(case.missing / (1 - case.missing)) + score)
    elif case.missing_mechanism == "clade":
        # Deliberate contiguous group loss, not an independent Bernoulli sample.
        return groups >= int(np.ceil(case.size * case.missing))
    else:
        raise ValueError(case.missing_mechanism)
    return rng.random(len(y)) >= probability


def generate_rsc(case, rng):
    counts = np.full(case.size, case.copies)
    if case.concentrated:
        counts[:] = 1
        counts[: max(2, case.size // 5)] = case.copies
    events = np.repeat(np.arange(case.size), counts)
    lineages = np.concatenate([np.arange(c) for c in counts])
    corr = np.full((case.predictors, case.predictors), case.correlation)
    np.fill_diagonal(corr, 1.0)
    event_x = rng.multivariate_normal(np.zeros(case.predictors), corr, case.size)
    x = event_x[events]
    beta = np.zeros(case.predictors)
    beta[0] = case.beta
    # Known conditional predictor uncertainty, shared by paralogs in an event.
    true_x = event_x + rng.normal(size=event_x.shape) * np.sqrt(case.predictor_variance)
    diagonal = np.ones(len(events))
    if case.working_covariance_dgm:
        diagonal *= counts[events]
    covariance = np.diag(diagonal)
    covariance += case.event_variance * (events[:, None] == events[None, :])
    if case.lineage_variance:
        for column in range(case.predictors):
            normalized = x[:, column] / np.sqrt(np.mean(event_x[:, column] ** 2))
            covariance += (
                case.lineage_variance
                * np.outer(normalized, normalized)
                * (lineages[:, None] == lineages[None, :])
            )
    sampling = np.full(len(events), case.sampling_variance / case.biological_replicates)
    covariance += np.diag(
        sampling * (counts[events] if case.working_covariance_dgm else 1)
    )
    y = true_x[events] @ beta + rng.multivariate_normal(
        np.zeros(len(events)), covariance
    )
    true_covariance = covariance + np.dot(beta, beta) * case.predictor_variance * (
        events[:, None] == events[None, :]
    )
    estimated_sampling = sampling.copy()
    if case.estimated_se:
        df = case.biological_replicates - 1
        if df < 1:
            raise ValueError("Estimated SE requires at least two biological replicates")
        estimated_sampling *= rng.chisquare(df, len(events)) / df
    keep = observed_mask(rng, case, x, y, events)
    return {
        "x": x[keep],
        "y": y[keep],
        "events": events[keep],
        "lineages": lineages[keep],
        "sampling": estimated_sampling[keep],
        "true_covariance": true_covariance[np.ix_(keep, keep)],
        "generated_rows": len(y),
        "generated_events": case.size,
        "removed_rows": int((~keep).sum()),
        "beta": beta,
    }


def generate_glmm(case, rng):
    tree, covariance = tree_covariance(case.size, case.tree_shape)
    copy_latent = rng.multivariate_normal(np.zeros(case.size), covariance)
    true_counts = rng.poisson(np.exp(np.log(2.0) + 0.5 * copy_latent))
    counts = true_counts.copy()
    if case.count_error:
        counts = rng.binomial(counts, 1 - case.count_error) + rng.poisson(
            case.count_error, case.size
        )
    x = np.log1p(counts).reshape(-1, 1)
    latent = rng.multivariate_normal(
        np.zeros(case.size), case.phylogenetic_variance * covariance
    )
    intercept = (
        np.log(case.baseline / (1 - case.baseline))
        if case.family == "binomial"
        else np.log(case.baseline)
    )
    eta = intercept + case.beta * np.log1p(true_counts) + latent
    if case.family == "binomial":
        y = rng.binomial(1, expit(eta))
    elif case.family == "poisson":
        y = rng.poisson(np.exp(eta))
    elif case.family == "negative-binomial":
        y = rng.negative_binomial(
            case.dispersion, case.dispersion / (case.dispersion + np.exp(eta))
        )
    else:
        raise ValueError(case.family)
    if case.zero_inflation:
        y[rng.random(case.size) < case.zero_inflation] = 0
    keep = observed_mask(rng, case, x, y, np.arange(case.size))
    return {
        "x": x[keep],
        "y": y[keep],
        "covariance": covariance[np.ix_(keep, keep)],
        "tree": tree,
        "retained_tips": np.flatnonzero(keep),
        "counts": counts[keep],
        "true_counts": true_counts[keep],
        "generated_rows": case.size,
        "removed_rows": int((~keep).sum()),
        "beta": np.array([case.beta]),
    }


def generate(case, seed):
    rng = np.random.default_rng(seed)
    return generate_rsc(case, rng) if case.engine == "rsc" else generate_glmm(case, rng)


def case_dict(case):
    return asdict(case)
